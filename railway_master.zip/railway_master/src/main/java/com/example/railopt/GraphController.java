package com.example.railopt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class GraphController {

    @Autowired
    private GraphService graphService;

    @PostMapping("/optimize")
    public GraphResult optimizeNetwork(@RequestBody GraphInput input) {
        return graphService.optimizeGraph(input);
    }
}