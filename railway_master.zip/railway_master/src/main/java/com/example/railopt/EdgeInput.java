package com.example.railopt;

public class EdgeInput {
    public int from;
    public int to;
    public int weight;
}