package com.example.railopt;

import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class GraphService {

    public GraphResult optimizeGraph(GraphInput input) {
        StringBuilder resultBuilder = new StringBuilder();

        int[][] adjMatrix = new int[input.nodes][input.nodes];
        for (EdgeInput edge : input.edges) {
            adjMatrix[edge.from][edge.to] = edge.weight;
        }

        resultBuilder.append("Dijkstra from source ").append(input.source).append(":\n");
        int[] dijkstra = dijkstra(adjMatrix, input.source);
        resultBuilder.append(Arrays.toString(dijkstra)).append("\n\n");

        resultBuilder.append("Floyd-Warshall All-Pairs Shortest Path:\n");
        int[][] floyd = floydWarshall(adjMatrix);
        for (int[] row : floyd) {
            resultBuilder.append(Arrays.toString(row)).append("\n");
        }

        resultBuilder.append("\nMax Flow from ").append(input.source).append(" to ").append(input.sink).append(":\n");
        int maxFlow = maxFlow(adjMatrix, input.source, input.sink);
        resultBuilder.append("Max Flow: ").append(maxFlow).append("\n");

        GraphResult result = new GraphResult();
        result.setMessage(resultBuilder.toString());
        return result;
    }

    private int[] dijkstra(int[][] graph, int src) {
        int V = graph.length;
        int[] dist = new int[V];
        boolean[] visited = new boolean[V];
        Arrays.fill(dist, Integer.MAX_VALUE);
        dist[src] = 0;

        for (int i = 0; i < V - 1; i++) {
            int u = minDistance(dist, visited);
            visited[u] = true;

            for (int v = 0; v < V; v++) {
                if (!visited[v] && graph[u][v] != 0 &&
                        dist[u] != Integer.MAX_VALUE &&
                        dist[u] + graph[u][v] < dist[v]) {
                    dist[v] = dist[u] + graph[u][v];
                }
            }
        }

        return dist;
    }

    private int minDistance(int[] dist, boolean[] visited) {
        int min = Integer.MAX_VALUE, minIndex = -1;
        for (int v = 0; v < dist.length; v++) {
            if (!visited[v] && dist[v] <= min) {
                min = dist[v];
                minIndex = v;
            }
        }
        return minIndex;
    }

    private int[][] floydWarshall(int[][] graph) {
        int V = graph.length;
        int[][] dist = new int[V][V];
        for (int i = 0; i < V; i++) {
            for (int j = 0; j < V; j++) {
                if (i == j) dist[i][j] = 0;
                else if (graph[i][j] == 0) dist[i][j] = Integer.MAX_VALUE / 2;
                else dist[i][j] = graph[i][j];
            }
        }

        for (int k = 0; k < V; k++) {
            for (int i = 0; i < V; i++) {
                for (int j = 0; j < V; j++) {
                    dist[i][j] = Math.min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }

        return dist;
    }

    private int maxFlow(int[][] graph, int s, int t) {
        int u, v;
        int V = graph.length;

        int[][] rGraph = new int[V][V];
        for (u = 0; u < V; u++)
            System.arraycopy(graph[u], 0, rGraph[u], 0, V);

        int[] parent = new int[V];
        int maxFlow = 0;

        while (bfs(rGraph, s, t, parent)) {
            int pathFlow = Integer.MAX_VALUE;
            for (v = t; v != s; v = parent[v]) {
                u = parent[v];
                pathFlow = Math.min(pathFlow, rGraph[u][v]);
            }

            for (v = t; v != s; v = parent[v]) {
                u = parent[v];
                rGraph[u][v] -= pathFlow;
                rGraph[v][u] += pathFlow;
            }

            maxFlow += pathFlow;
        }

        return maxFlow;
    }

    private boolean bfs(int[][] rGraph, int s, int t, int[] parent) {
        boolean[] visited = new boolean[rGraph.length];
        Queue<Integer> queue = new LinkedList<>();
        queue.add(s);
        visited[s] = true;
        parent[s] = -1;

        while (!queue.isEmpty()) {
            int u = queue.poll();
            for (int v = 0; v < rGraph.length; v++) {
                if (!visited[v] && rGraph[u][v] > 0) {
                    queue.add(v);
                    parent[v] = u;
                    visited[v] = true;
                }
            }
        }

        return visited[t];
    }
}