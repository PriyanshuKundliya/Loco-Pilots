package com.example.railopt;

import java.util.List;

public class GraphInput {
    public List<EdgeInput> edges;
    public int nodes;
    public int source;
    public int sink;
}