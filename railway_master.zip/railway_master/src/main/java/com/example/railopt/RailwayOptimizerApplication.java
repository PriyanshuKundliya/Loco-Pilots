package com.example.railopt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwayOptimizerApplication {
    public static void main(String[] args) {
        SpringApplication.run(RailwayOptimizerApplication.class, args);
    }
}